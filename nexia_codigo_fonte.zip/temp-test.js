const sdk = require('@deepgram/sdk');
console.log('SDK Exports:', Object.keys(sdk));